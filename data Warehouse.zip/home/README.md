Project Purpose :
     In this project, i created a ETL pipeline that extracts data from AWS S3 , stages tables on AWS Redshift, and execute SQL Queries statements.
     
DATA BASE SCHEMA :
      FACT TABLE:
           songplays - records in log data associated with song plays i.e. records with page NextSong
           Columns will be ongplay_id, start_time, user_id, level, song_id, artist_id, session_id, location, user_agent
      DIMENSION TABLE:
          1.users - users in the app
            Columns will be user_id, first_name, last_name, gender, level
          2.songs - songs in music database
            Columns will be song_id, title, artist_id, year, duration
          3.artists - artists in music database
             Columns will be artist_id, name, location, latitude, longitude
          4.time - timestamps of records in songplays broken down into specific units
             Columns will be start_time, hour, day, week, month, year, weekday
       STAGING_SONGS:
                    information regarding songs and artists
       STAGING_EVENTS:-
                    collected information which song is listening by user

Python scripts: 
     etl.py: is used to build ETL processes which will read JSON data from S3bucket to redshift 
     sql_queries.py:  is used for writing SQL statements and to resolve query and finally 
     dhw.cfg: this file contains information regarding Redshift, IAM and S3  

EXPLANATION:
     To create the sparkifydb database, i used to run create_tables.py from the terminal, i used to run etl.py for ETL process.