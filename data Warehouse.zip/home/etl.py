import configparser
import psycopg2
from sql_queries import copy_table_queries, insert_table_queries


def load_staging_tables(cur, conn):
    """
    - load staging table from s3 bucket in this function
     
    """
    for query in copy_table_queries:
        cur.execute(query)
        conn.commit()


def insert_tables(cur, conn):
    """""
        - Create table using the queries in 'insert_table_queries' list
        - Returns the connection and cursor to sparkifydb
    """""
    for query in insert_table_queries:
        cur.execute(query)
        conn.commit()


def main():
    config = configparser.ConfigParser()
    config.read('dwh.cfg')
    """
       - read the file details for dwh.cfg host, dbname,user password, port details
    """

    conn = psycopg2.connect("host={} dbname={} user={} password={} port={}".format(*config['CLUSTER'].values()))
    cur = conn.cursor()
    """  
    - load staging all the tables, insert all tables needed. 
    - Finally, closes the connection. 
    """
    load_staging_tables(cur, conn)
    insert_tables(cur, conn)

    conn.close()


if __name__ == "__main__":
    main()